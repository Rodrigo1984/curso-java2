
public record Quadrado(double lado) {

	public double calcularArea() {
		return lado * lado;
	}
}
