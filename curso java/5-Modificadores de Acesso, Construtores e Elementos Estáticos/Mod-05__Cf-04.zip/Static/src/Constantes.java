
public class Constantes {

	public static final double MEDIA_DA_PROVA;
	
	static {
		MEDIA_DA_PROVA = 7.0;
	}
}
