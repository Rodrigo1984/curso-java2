
public class Aplicacao {

	public static void main(String[] args) {
	
//		Matematica m = new Matematica();
//		int soma = m.somar(10, 5);
//		int subtracao = m.subtrair(50, 10);
		
//		int soma = Matematica.somar(10, 5);
//		int subtracao = Matematica.subtrair(50, 10);
//		
//		System.out.println(soma);
//		System.out.println(subtracao);
		
//		System.out.println(Contador.valor);
//		
//		Contador.incrementar();
//		Contador.incrementar();
//		Contador.incrementar();
//		
//		System.out.println(Contador.getValor());

		double media = Constantes.MEDIA_DA_PROVA;
		System.out.println(media);
	}
}
