
public interface ItemCaro {

	double getPreco();
}
