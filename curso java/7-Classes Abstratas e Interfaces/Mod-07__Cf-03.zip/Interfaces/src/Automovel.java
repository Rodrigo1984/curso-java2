
public interface Automovel {

	void virarEsquerda();
	void virarDireita();
	void acelerar();
	
}
