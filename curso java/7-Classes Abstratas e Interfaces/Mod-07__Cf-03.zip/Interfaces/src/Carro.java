
public interface Carro extends Automovel {

	void abrirPorta();
}
