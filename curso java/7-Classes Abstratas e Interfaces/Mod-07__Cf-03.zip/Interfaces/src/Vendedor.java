
public class Vendedor {

	public void mostrarPreco(ItemCaro item) {
		System.out.println("O valor � " + item.getPreco());
	}
}
