
public class AnelBrilhante implements ItemCaro {

	@Override
	public double getPreco() {
		return 50000;
	}
}
