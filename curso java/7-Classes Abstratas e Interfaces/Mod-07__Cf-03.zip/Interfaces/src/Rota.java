
public class Rota {

	public void ir(Automovel a) {
		
		a.acelerar();
		a.virarDireita();
		a.virarEsquerda();
		a.virarDireita();
	}
}
