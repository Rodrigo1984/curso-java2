

public interface AreaCalculavel {

	//m�todo para calcular �rea. Deve ser implementado pelas classes que implementam esta interface
	double calcularArea();
}
