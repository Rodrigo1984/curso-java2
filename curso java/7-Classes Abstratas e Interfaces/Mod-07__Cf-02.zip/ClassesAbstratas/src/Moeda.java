
public class Moeda extends Item {

	@Override
	public void pegar() {
		System.out.println("Pegou a moeda");
	}
}
