
public class Cogumelo extends Item {

	@Override
	public void pegar() {
		System.out.println("Pegou o cogumelo");
	}
}
