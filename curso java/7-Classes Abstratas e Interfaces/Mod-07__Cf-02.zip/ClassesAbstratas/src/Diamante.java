
public class Diamante extends Item {

	@Override
	public void pegar() {
		System.out.println("Pegou o diamante");
	}
}
