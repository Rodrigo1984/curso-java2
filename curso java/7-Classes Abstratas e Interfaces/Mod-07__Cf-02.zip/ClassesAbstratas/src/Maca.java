
public class Maca extends Item {

	@Override
	public void pegar() {
		System.out.println("Pegando a ma��");
	}
}
