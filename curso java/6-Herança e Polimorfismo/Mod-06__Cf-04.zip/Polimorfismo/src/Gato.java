
public class Gato extends Animal {

	@Override
	public void falar() {
		System.out.println("MIAU");
	}
}
