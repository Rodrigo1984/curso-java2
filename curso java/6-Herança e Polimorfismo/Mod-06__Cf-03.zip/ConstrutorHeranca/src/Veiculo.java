
public class Veiculo {

	protected String marca;
	
	public Veiculo(String marca) {
		this.marca = marca;
		System.out.println("Veiculo(String)");
	}
}
