
public class Aplicacao {

	public static void main(String[] args) {
		
		Carro c = new Carro("Ferrari");
		
	}
}
