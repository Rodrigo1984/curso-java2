
public class Carro extends Veiculo {

	public Carro(String marca) {
		super(marca);
		System.out.println("Carro(String)");
	}
}
