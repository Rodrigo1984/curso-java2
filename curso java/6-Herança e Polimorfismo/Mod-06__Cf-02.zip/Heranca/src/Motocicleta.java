
public class Motocicleta extends Veiculo {

	public void empinar() {
		System.out.println("UHU!");
	}
}
