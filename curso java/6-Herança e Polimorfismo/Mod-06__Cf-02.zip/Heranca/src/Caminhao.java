
public class Caminhao extends Veiculo {

	@Override
	public void buzinar() {
		System.out.println("FOM FOM");
	}
}
