
public class Pais {
	private String nome;
	
	public String getNome() {
		return nome;
	}
}
