
public class Estado {
	private Pais pais = new Pais();
	
	public Pais getPais() {
		return pais;
	}
}
