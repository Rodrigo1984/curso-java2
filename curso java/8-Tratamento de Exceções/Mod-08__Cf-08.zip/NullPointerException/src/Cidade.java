
public class Cidade {

	private Estado estado = new Estado();
	
	public Estado getEstado() {
		return estado;
	}
}
