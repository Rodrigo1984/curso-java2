
@SuppressWarnings("serial")
public class AcimaVelocidadeMaximaException extends Exception {

	public AcimaVelocidadeMaximaException(String message) {
		super(message);
	}
}
