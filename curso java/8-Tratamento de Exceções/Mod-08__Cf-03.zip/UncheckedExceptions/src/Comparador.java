
public class Comparador {

	public static boolean comparar(Object o1, Object o2) {
		return o1.equals(o2);
	}
}
